/* ���ؽ� ���� led-ultrasonic
gcc -D_REENTRANT dbserver.c -o dbserver -lpthread -lwiringPi -lm -lmysqlclient
sudo ./dbserver <port>

gcc -o dbserver dbserver.c -lpthread -lwiringPi -lm -lmysqlclient
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<wiringPi.h>
#include<pthread.h>
#include<mysql/mysql.h>

#define PORT 9000
#define DBHOST "127.0.0.1"
#define DBUSER "root"			//mysql id : root
#define DBPASS "abcd1234"		//mysql pwd : 
#define DBNAME "project"		//dbname 
#define MAX 5
#define MIN 0

int clnt_number=0;
int clnt_socks[10];
pthread_mutex_t mutx;
char *tokBuf1, *tokBuf2;
int gas[MAX];
int average[MAX];
int cnt=0;

void setup(){
	if(wiringPiSetup() == -1){
		exit(1);
	}
}

//Co gas avg
int gasAvg(int *array,int cnt) {
	int i,j=0;
	int sum=0;
	int avg=0;
	for(i=MIN;i<MAX;i++) {
		sum+=array[i];
		j++;
	}
	avg = sum / j;
	return avg;
}

//avg Phase
int Phase(int avg) {

	if(avg>=40 && avg<=51)
		return 1;
	else if(avg>=102 && avg<=204)
		return 2;
	else if(avg>=409 && avg<=511)
		return 3;
	else if(avg>=613 && avg<=716)
		return 4;
	else if(avg>=818)
		return 5;
}
void printText(int flag,int data) {
	
	if(flag==3 && data==0)
		printf("many gas detected\n");
	else if(flag==4 &&data==0)
		printf("aware fire!!!!\n");
	else if(flag==5&& data==0)
		printf("please run away from here!!!!!!\n");

}

void* c_work(void *arg){
	int c_sock = (int)arg;
	int str_len = 0;
	int i,j,k;
	char buffer[BUFSIZ];
	MYSQL *mysql; // execute mysql
	mysql = mysql_init(NULL);
	int avg=0;
	int fire;
	int phaseFlag;
	int avgComp;

	int avalue[2] = {0};

	if (!mysql_real_connect(mysql, DBHOST, DBUSER, DBPASS, DBNAME, 3306, NULL, 0)) {
		return 0;
	}//try connect MYSQL

	printf("mysql opened!\n");


//input data to MYSQL database, it will be inputed to String type (use varchar() type)


	while((str_len = read(c_sock, buffer, sizeof(buffer))) != 0) {
			char query[1024];
		//printf("Recived: %s\n", buffer);
			if(!strncmp(buffer, "Val", 3)){ 
				if(strtok_r(buffer,":",&tokBuf1)) {
						gas[cnt]=atoi(tokBuf1);
						cnt++;
						if(cnt==5) {
							cnt=0;
						}
					if(strtok_r(tokBuf1,";",&tokBuf2)) { 
						fire=atoi(tokBuf2);
					}
				}
				avg=gasAvg(gas,cnt);
				
				sprintf(query, "insert into detect values(%d, %d, %d)",atoi(tokBuf1),atoi(tokBuf2),avg);
			} 

			printf("gasValue:%d fireValue:%d\n",atoi(tokBuf1),atoi(tokBuf2));
			delay(1000);
			
			phaseFlag = Phase(avg);
			printText(phaseFlag,atoi(tokBuf2));


			if (mysql_query(mysql, query)) {
				fprintf(stderr, "%s\n", mysql_error(mysql));
				printf("write dberror\n");			
		}
	
		memset(buffer, 0, sizeof(buffer));
	}
	
	pthread_mutex_lock(&mutx);
	for(i = 0; i < clnt_number; i++){
		if(c_sock == clnt_socks[i]){
			for(; i < clnt_number-1; i++){
				clnt_socks[i] = clnt_socks[i+1];
				break;
			}
		}
	}

	clnt_number--;
	pthread_mutex_unlock(&mutx);
	close(c_sock);
	mysql_close(mysql);
	return 0;
}

int main() {
	int s_socket, c_socket;
	struct sockaddr_in s_addr, c_addr;
	int len;
	pthread_t thread;
	void *thread_result;

	setup();

	if(pthread_mutex_init(&mutx, NULL)){
		printf("mutex init error\n");
		exit(1);
	}

	s_socket = socket(PF_INET, SOCK_STREAM, 0);

	if(s_socket == -1){
		printf("s_socket create faild\n");
		exit(1);
	}

	memset(&s_addr, 0, sizeof(s_addr));
	s_addr.sin_family = AF_INET;
	s_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	s_addr.sin_port = htons(PORT);

	if(bind(s_socket, (struct sockaddr*)&s_addr, sizeof(s_addr)) ==  -1){
		printf("Can not bind\n");
		exit(1);
	}
	if(listen(s_socket, 5) == -1){
		printf("Can not listen\n");
		exit(1);
	}
	printf("Server : READY\n");

	while(1){
		len = sizeof(c_addr);
		c_socket = accept(s_socket, (struct sockaddr*)&c_addr, &len);
		if(c_socket == -1){
			printf("Client accept faild.\n");
			exit(1);
		}
		printf("Server : Client connected\n");

		pthread_mutex_lock(&mutx);
		clnt_socks[clnt_number++] = c_socket;
		pthread_mutex_unlock(&mutx);

		pthread_create(&thread, NULL, c_work, (void*)c_socket);
		//pthread_join(thread, &thread_result);
		
	}
	close(s_socket);

	return 0;
}