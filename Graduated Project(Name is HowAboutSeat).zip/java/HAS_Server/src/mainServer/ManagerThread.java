package mainServer;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class ManagerThread extends Thread{

	private final int PORT = 9002;

	ServerSocket server = null;
	Socket socket = null;

	ManagerThread() {
		try {
			server = new ServerSocket(PORT);
		} catch (IOException e) { e.printStackTrace(); }
	}

	public void run() {
		try {
			while( (socket = server.accept()) != null ) {
				new SocketThread(socket).start();
			}
		} catch (IOException e) { e.printStackTrace(); }
	}
}

class SocketThread extends Thread {
	Socket socket;

	SocketThread(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		InetSocketAddress isaClient = (InetSocketAddress) socket.getRemoteSocketAddress(); //연결된 클라이언트의 정보를 가져오기 위한 변수 선언
		String clientAddress = isaClient.getAddress().getHostAddress(); //클라이언트의 정보에서 host 주소를 저장하는 변수 선언
		System.out.println("Manager connected. (" + clientAddress +")");

		try {
			InputStream is = socket.getInputStream();
			DataInputStream dis = new DataInputStream(is);

			String pcname = dis.readUTF();
			
			DBClass db = new DBClass();
			String filename = db.getFileName(pcname);

			if(filename != null) {
				File f = new File(pcname + "/" + filename);
				FileInputStream fis = new FileInputStream(f);
				OutputStream os = socket.getOutputStream();

				byte[] buffer = new byte[8192];
				int readBytes;

				while( (readBytes = fis.read(buffer)) > 0 ) {
					os.write(buffer, 0 , readBytes);
				}

				fis.close();
				os.close();
				db.close();
				System.out.println("File Send OK!");
			}

			dis.close();
			is.close();

		} catch (IOException e) { e.printStackTrace(); }
	}
}
