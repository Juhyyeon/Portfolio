package mainServer;

import java.util.Timer;
import java.util.TimerTask;

public class ServerMain {

	private int TIMER = 0;
	private int PERIOD = 60;
	
	ServerMain() {
		FileReciever fr = new FileReciever();
		fr.start();
		
		ManagerThread fs = new ManagerThread();
		fs.start();
		
		Timer term = new Timer();
		TimerTask termTask = new TimerTask() {
			@Override
			public void run() {
				TIMER++;
				if(TIMER >= PERIOD) {
					new SendToCalc();
					TIMER = 0;
				}
			}
		};
		
		term.schedule(termTask, 5, 1000);
	}
	
	public static void main(String[] args) {
		System.out.println("Server Start!");
		
		new ServerMain();
	}

}