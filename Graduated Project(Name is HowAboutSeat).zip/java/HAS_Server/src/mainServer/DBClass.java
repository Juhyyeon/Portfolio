/*
 * Main Server 용 DBClass
 * url => localhost
 */

package mainServer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DBClass {
	
	private final String jdbc = "org.mariadb.jdbc.Driver";
	private final String url = "jdbc:mariadb://127.0.0.1:3306/mainserver";
	private final String userID = "test";
	private final String userPW = "1234";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	DBClass() {
		try {
			Class.forName(jdbc);
			conn = DriverManager.getConnection(url, userID, userPW);
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public void newPCRoom(String name) {
		String query = "insert into pcroom(pcname) values(?)";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
	}
	
	public void updatePCRoom(String name, String file) {
		String query = "update pcroom set filename = ? where pcname = ?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, file);
			pstmt.setString(2, name);
			pstmt.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
	}
	
	public String getFileName(String name) {
		String query = "select filename from pcroom where pcname = ?";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			
			rs.next();
			return rs.getString(1);
			
		} catch (SQLException e) { e.printStackTrace(); return null; }		
	}
	
	public ArrayList<String[]> getPCRoomList() {
		String query = "select pcname, filename from pcroom where care = ?";
		ArrayList<String[]> list = new ArrayList<String[]>();
				
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, 1);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String[] temp = { rs.getString(1), rs.getString(2) };
				list.add(temp);
			}
		} catch (SQLException e) { e.printStackTrace(); }
		
		return list;
	}
	
	public ArrayList<String[]> getExeServer() {		
		ArrayList<String[]> list = new ArrayList<String[]>();
		String query = "select address, port from exeserver";
		
		try {
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String[] temp = { rs.getString(1), rs.getString(2) };
				list.add(temp);
			}
			
		} catch (SQLException e) { e.printStackTrace(); }
		
		return list;
	}
	
	public void close() {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			conn.close();
		} catch (SQLException e) { e.printStackTrace(); }
	}
	
}