/*
 * mainServer SendToCalc
 * @@ 분산처리 사용할 적절한 알고리즘 생각해 볼것 
 * @@ 현재는 균등 분배 방식
 */

package mainServer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

public class SendToCalc {
	private static final int STRING_SIZE = 64; // 전송할 문자열 길이
	private static final int BUFF_SIZE = 1024; // 버퍼 사이즈

	SendToCalc() {
		DBClass db = new DBClass();
		ArrayList<String[]> pcroom = db.getPCRoomList();
		ArrayList<String[]> exeserver = db.getExeServer();
		db.close();

		int pcSize = pcroom.size();
		int exeSize = exeserver.size();

		System.out.println("Managing Spot Count = "+pcSize);
		System.out.println("EXE Server Count = "+exeSize);

		if(pcSize != 0 && exeSize != 0) {
			int exeCnt = -1;

			for(int pcCnt=0; pcCnt<pcSize; pcCnt++) {
				exeCnt = (exeCnt + 1) % exeSize;
				SendSocket(pcroom.get(pcCnt), exeserver.get(exeCnt));
				System.out.printf("%s send to Server %d\n", pcroom.get(pcCnt)[0], exeCnt+1);
			}	
		}
	}

	void SendSocket(String[] pcroom, String[] server) {
		// pcroom[0] = PC방 이름, pcroom[1] = 이미지 파일 이름

		Socket socket = new Socket();
		OutputStream os = null;
		File imgf = null;

		InetSocketAddress inet = new InetSocketAddress(server[0], Integer.parseInt(server[1]));
		try {
			socket.setReuseAddress(true);
			socket.connect(inet);
			socket.setSoTimeout(10000);

			// 출력용 스트림 지정
			os = socket.getOutputStream();

			// 파일 크기 확인
			imgf = new File(pcroom[0]+"/"+pcroom[1]);
			long imgSize = imgf.length();

			// JAVA - C 소켓 통신은 Byte 단위로 처리해야 하므로 ByteBuffer 사용하여 데이터 변환
			ByteBuffer sender = null;

			// PC방 명 전송
			// JAVA는 빅 엔디안으로 모든 데이터를 저장하기 때문에 C에서 사용하는 리틀 엔디안으로 변환
			sender = ByteBuffer.allocate(STRING_SIZE);
			sender.order(ByteOrder.LITTLE_ENDIAN);
			// PC방 명 Byte로 변환하여 전송 
			sender.put(pcroom[0].getBytes());
			sender.put(new byte[STRING_SIZE - pcroom[0].getBytes().length]);
			os.write(sender.array());
			os.flush();
			// 파일 크기 역시 일반적인 long이나 int형 데이터여도 Byte 단위로 변환하여 보내야 하므로 변환
			// 마찬가지로 빅 엔디안 -> 리틀 엔디안으로 변환 하여 전송
			sender = ByteBuffer.allocate(8);
			sender.order(ByteOrder.LITTLE_ENDIAN);
			sender.putLong(imgSize);
			os.write(sender.array());
			os.flush();


			// 파일을 바이트 단위로 읽기 위한 파일 스트림 생성
			FileInputStream fin = new FileInputStream(imgf);

			// 파일 전송용 버퍼
			byte[] buffer = new byte[BUFF_SIZE];

			// 전송된 크기 저장할 변수
			int len;

			// 파일의 사이즈만큼
			while (imgSize > 0) {
				// 버퍼에 byte로 저장하여 전송
				len = fin.read(buffer);				
				os.write(buffer, 0, len);
				os.flush();
				imgSize = imgSize - len;
			}

			fin.close();
			socket.close();
			os.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
