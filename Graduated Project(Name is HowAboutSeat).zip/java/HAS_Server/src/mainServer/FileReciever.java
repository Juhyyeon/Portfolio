/*
 * mainServer FileReciever
 * @@ 파일 갯수 새서 가장 마지막 파일 삭제하는 기능 구현 필요
 */

package mainServer;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.StringTokenizer;

public class FileReciever extends Thread {
	
	private final int PORT = 9001;
	
	ServerSocket server = null;
	Socket socket = null;
	
	FileReciever() {
		try {
			server = new ServerSocket(PORT);
			
			System.out.println("Server Ready...");
			
		} catch (IOException e) { e.printStackTrace(); }
	}
	
	@Override
	public void run() {
		try {
			while( (socket = server.accept()) != null ) {
				new RecieverThread(socket).start();
			}
		} catch (IOException e) { e.printStackTrace(); }
	}	
}

class RecieverThread extends Thread {
	
	Socket socket;
	String[] content = new String[3];
	
	RecieverThread(Socket socket) {
		this.socket = socket;
	}
	
	@Override
	public void run() {
		
		// 연결 정보 확인
		InetSocketAddress isaClient = (InetSocketAddress) socket.getRemoteSocketAddress(); //연결된 클라이언트의 정보를 가져오기 위한 변수 선언
		String clientAddress = isaClient.getAddress().getHostAddress(); //클라이언트의 정보에서 host 주소를 저장하는 변수 선언
		System.out.println("Reciever : Client connected. (" + clientAddress +")");
		
		try {
			InputStream is = socket.getInputStream();
			DataInputStream dis = new DataInputStream(is); //전송받은 데이터를 받기위한 DataInputStream 변수 선언
			StringTokenizer st = new StringTokenizer(dis.readUTF(), "/"); // 데이터를 '/'로 구분하여 받았으므로 Tokenizer 사용
			
			DBClass db = new DBClass();
			
			while(st.hasMoreTokens()) {
				for(int i=0;i<content.length;i++) {
					content[i] = st.nextToken(); 
				}
			}
			// content[0] = PC방 명, content[1] = 파일명(파일 생성 날짜), content[2] = 해쉬값
			
			File f = new File(content[0]);
			if(!f.exists()) {
				f.mkdir();
				db.newPCRoom(content[0]);
			}
			
			if(f.isDirectory()) {
				FileOutputStream fos = new FileOutputStream(content[0] +"/" + content[1]);
				byte[] buffer = new byte[8192];
				int readBytes;
				
				while ((readBytes = is.read(buffer)) != -1) {
					fos.write(buffer, 0, readBytes);
				}
				fos.close();
				
				System.out.println(makeHashSHA256(content[0] + "/" + content[1]).equals(content[2]));
				
				db.updatePCRoom(content[0], content[1]);
				
				String[] fileList = f.list();
				
				if(fileList.length > 5) {
					Arrays.sort(fileList, String.CASE_INSENSITIVE_ORDER);
					System.out.println(fileList[0]);
					System.out.println(fileList[1]);
					System.out.println(fileList[2]);
					File ft = new File(content[0] + "/" + fileList[0]);
					ft.delete();
					System.out.println(fileList[0] + " is Deleted");
				}
			}
			
			
			db.close();
			dis.close();
			is.close();
			
			System.out.println("File Recieve OK!");
			
		} catch (Exception e) { e.printStackTrace(); }
		
	}
	
	String makeHashSHA256(String filename) throws Exception 
	{

		String SHA = "";
		int buff = 16384;
		try {
			RandomAccessFile file = new RandomAccessFile(filename, "r");

			MessageDigest hashSum = MessageDigest.getInstance("SHA-256");

			byte[] buffer = new byte[buff];
			byte[] partialHash = null;

			long read = 0;

			// calculate the hash of the hole file for the test
			long offset = file.length();
			int unitsize;
			while (read < offset) {
				unitsize = (int) (((offset - read) >= buff) ? buff : (offset - read));
				file.read(buffer, 0, unitsize);

				hashSum.update(buffer, 0, unitsize);

				read += unitsize;
			}

			file.close();
			partialHash = new byte[hashSum.getDigestLength()];
			partialHash = hashSum.digest();

			StringBuffer sb = new StringBuffer();
			for(int i = 0 ; i < partialHash.length ; i++){
				sb.append(Integer.toString((partialHash[i]&0xff) + 0x100, 16).substring(1));
			}
			SHA = sb.toString();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		return SHA;
	}
	
}