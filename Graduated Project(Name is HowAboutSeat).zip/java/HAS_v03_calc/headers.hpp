// OPENCV
#include "opencv2/opencv.hpp"

// STANDARD
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// SOCKET
#include <fcntl.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>

// Thread
#include <pthread.h>

// MYSQL
#include "mysql/mysql.h"

// 좌석 좌표 저장 구조체
struct _seat{
	int seatnum;
	int locX;
	int locY;
	char empty;
};

struct _dbinfo{
	char HOST[50];
	char USER[20];
	char PASS[20];
	char NAME[20];
	int PORT;
};
