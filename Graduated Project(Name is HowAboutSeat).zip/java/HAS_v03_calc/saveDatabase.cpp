#include "headers.hpp"

#define DBFILE "db.txt"

#define BUFFSIZE 1024

// 좌석 좌표 저장 구조체 -> headers.hpp에 정의 되어 있음
typedef struct _seat Seat;

// DB 정보 구조체, 보기 편하기 위해 구현
typedef struct _dbinfo DBInfo;

// saveDatabase(피시방 이름, 구조체 포인터, 자리 수)
void saveDatabase(char* name, Seat* seats, int length) {

	// 파일에서 DB정보 가져오기! >> 앞으로의 유지 보수를 위하여...
	printf("DB File Read...");

	DBInfo info;
	File *fp; fp = fopen(DBFILE, "r");
	while(! feof(fp) ){
		fscanf(fp, "SERVER : %s\nPORT : %d\nUSER : %s\nPASSWORD : %s\nDBNAME : %s\n=END=\n",
			info.HOST, &info.PORT, info.USER, info.PASS, info.NAME);
	} fclose(fp);

	printf("DB File OK!");
	
	
	MYSQL *mysql;
	mysql = mysql_init(NULL);
	int count = 0;

	if( !mysql_real_connect(mysql, info.HOST, info.USER, info.PASS, info.NAME, info.PORT, NULL, 0) ) {
		printf("MYSQL ERROR!\n");
		return;
	}

	char query[BUFFSIZE];

	// 자리수 만큼 반복해서 데이터베이스 갱신
	for(int i=0; i<length; i++) {
		memset(query, 0, BUFFSIZE);
		
		// 총 빈자리 카운트
		if(seats[i].empty == 'Y') {
			count++;
		}		

		// PC방 이름으로 된 테이블에 1번 자리부터 반복하여 데이터 저장
		sprintf(query, "update %s set empty = '%c' where seatnum = %d", name, seats[i].empty, seats[i].seatnum);
		if( mysql_query(mysql, query) ) {
			fprintf(stderr, "%s\n", mysql_error(mysql));
			printf("UPDATE ERROR!\n");
			return;
		}
	}

	// 총 빈자리 수 업데이트
	memset(query, 0, BUFFSIZE);
	sprintf(query, "update pcroom_list set emptyseat = %d where pcname = '%s'", count, name);
	if( mysql_query(mysql, query) ) {
		fprintf(stderr, "%s\n", mysql_error(mysql));
		printf("UPDATE ERROR!\n");
		return;
	}

	mysql_close(mysql);
	return;
}