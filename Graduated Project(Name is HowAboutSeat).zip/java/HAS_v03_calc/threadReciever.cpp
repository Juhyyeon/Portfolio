#include "headers.hpp"

// DATA_SIZE는 JAVA와 몇 바이트씩 문자열 통신을 할 것인지 맞춰야 한다
#define DATA_SIZE 64

// 파일 수신 버퍼 사이즈 역시 JAVA와 몇 바이트씩 통신을 할 것인지 맞춰야 한다
#define BUFFSIZE 1024

// main 소스의 소켓통신 저장용 전역 변수
extern int client_socket[];
extern int client_number;
extern pthread_mutex_t mutx;

extern int imgCalculator(char* imgname, char* pcname);

void* threadReciever(void* arg){	
	// 소켓 정보
	uintptr_t k = (uintptr_t) arg;
	int c_fd = (int) k;

	// 수신할 변수들
	char pcname[DATA_SIZE];
	long long int imgsize;

	// 파일 수신용 버퍼, 파일 수신 크기 변수
	char temp[BUFFSIZE];
	int rcvd;

	// PC방 명, 이미지 파일크기 순으로 수신
	memset(pcname, 0, DATA_SIZE);
	recv(c_fd, pcname, DATA_SIZE, MSG_WAITALL);
	
	char testmsg[DATA_SIZE] = "Test Server";
	
	if(strcmp(pcname, testmsg) == 0){
		send(c_fd, testmsg, DATA_SIZE, MSG_DONTWAIT);
		
		printf("TEST OK!\n");
		
		pthread_mutex_lock(&mutx);
		for(int i = 0; i < client_number; i++){
			if(c_fd == client_socket[i]){	
				for(; i < client_number-1; i++){
					client_socket[i] = client_socket[i+1];
					break;
				}
			}
		}
		client_number--;
		pthread_mutex_unlock(&mutx);
		
		fflush(stdout);
		pthread_exit(NULL);
	}

	recv(c_fd, &imgsize, sizeof(long long int), MSG_WAITALL);
	long long int imgcalc = imgsize;


	// 받아온 PC 방 이름으로 파일명 설정하여 파일 생성
	FILE *fp;

	char imgname[DATA_SIZE];
	strcpy(imgname, pcname);	
	const char *str2 = "_new.png";
	strcat(imgname, str2);

	fp = fopen(imgname, "wb");

	// 정확한 파일 계산을 위한 버퍼 크기 저장변수
	int tempsize = BUFFSIZE;
	
	// 이미지 파일부터 수신
	// 파일을 전부 받을 동안
	while(imgcalc > 0) {
		// 만약, 버퍼 크기보다 남은 파일 용량이 적을 경우, 적은 용량만큼만 파일에 기록한다.
		// 하지 않을 경우 파일이 변조될 가능성이 있다
		if(imgcalc < BUFFSIZE)	{
			tempsize = imgcalc;
		}
		// 버퍼 크기만큼 버퍼에 데이터 수신하여 파일에 기록한다.
		rcvd = recv(c_fd, temp, tempsize, MSG_WAITALL);
		fwrite(temp, sizeof(char), rcvd, fp);
		imgcalc = imgcalc - rcvd;
	}
	fclose(fp);

	// 이미지 수신 확인용 
	printf("PC NAME = %s, IMG NAME = %s", pcname, imgname);

	// 수신이 완료되면 수신된 파일 이름을 imgCalculator 함수에 넘겨준다
	imgCalculator(imgname, pcname);
	
	pthread_mutex_lock(&mutx);
	for(int i = 0; i < client_number; i++){
		if(c_fd == client_socket[i]){
			for(; i < client_number-1; i++){
				client_socket[i] = client_socket[i+1];
				printf("DISCONNECT!\n");
				break;
			}
		}
	}
	client_number--;
	pthread_mutex_unlock(&mutx);

	fflush(stdout);

	return 0;
}
