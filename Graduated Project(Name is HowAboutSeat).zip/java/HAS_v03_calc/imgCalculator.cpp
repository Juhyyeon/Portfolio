#include "headers.hpp"
using namespace cv;

// 좌석 좌표 저장 구조체 -> headers.hpp에 정의 되어 있음
typedef struct _seat Seat;

extern void saveDatabase(char* name, Seat* seats, int length);
extern Seat* seatInfoLoad(char* pcname, int* refX, int* refY, int* numSeat);

// Histogram 변환시 사용되는 변수들
int histSize[] = { 50, 60 };
float h_ranges[] = { 0, 180 };
float s_ranges[] = { 0, 256 };
const float* ranges[] = { h_ranges, s_ranges };
int channels[] = { 0, 1 };

// compareHist를 위한 Mat -> MatND 변환 함수
void convertHist(Mat* RGB, MatND* HIST){
	Mat HSV;
	cvtColor(*RGB, HSV, COLOR_BGR2HSV);
	calcHist(&HSV, 1, channels, Mat(), *HIST, 2, histSize, ranges, true, false);
	normalize(*HIST, *HIST, 0, 1, NORM_MINMAX, -1, Mat());
}

void imgCalculator(char* imgname, char* pcname) {

	Mat imgSrc = imread(imgname, CV_LOAD_IMAGE_COLOR);
	if(!imgSrc.data){
		printf("ERROR READ IMAGE\n");
		return;
	}

	// old / new 비교 구현할것! 일단 비교없이 파일명 변경
	char filename[64];
	strcpy(filename, pcname);
	const char *str2 = "_old.png";
	strcat(filename, str2);
	rename(imgname, filename);

	char refname[64];
	strcpy(refname, pcname);
	const char *str3 = "_ref.png";
	strcat(refname, str3);

	int refX, refY, numSeat;

	Seat* seats = seatInfoLoad(pcname, &refX, &refY, &numSeat);
	
	Mat rgbStd = imread(refname, CV_LOAD_IMAGE_COLOR);	
	MatND histStd;
	convertHist(&rgbStd, &histStd);


	// 받아온 시작 좌표로 이미지 분할후 compareHist로 비교
	for(int j=0; j<numSeat; j++){
		int tempY = seats[j].locY; int tempX = seats[j].locX;		
		Mat rgbTemp = imgSrc(Range(tempY, tempY+refY), 
			Range(tempX, tempX+refX));				
		MatND histTemp;
		convertHist(&rgbTemp, &histTemp);
		double emptyTemp = compareHist(histStd, histTemp, 0);
		if(emptyTemp > 0.5){
			seats[j].empty = 'Y';
		}
		else{
			seats[j].empty = 'N';
		}		
	}

	// 콘솔에서 테스트 용 for문, 필요할 시 주석 치워서 사용할 것	

	
	for(int j=0; j<numSeat; j++){
		if(seats[j].empty == 'Y'){
			printf("%d번째 자리 = 빈자리", j+1);
		}

		else{
			printf("%d번째 자리 = 사용중", j+1);
		}
		printf("\n");
	}

	// 계산 마친 후 계산 정보들을 saveDatabase 함수에 넘겨서 데이터베이스에 저장
	// saveDatabase(피시방 이름, 구조체 포인터, 자리 수)
	saveDatabase(pcname, seats, numSeat);

	free(seats);
	

	printf("%s OK!\n", pcname);
}