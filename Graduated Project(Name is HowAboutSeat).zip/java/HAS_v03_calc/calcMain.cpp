#include "headers.hpp"

// 서버 포트
#define PORT 9900

// 최대 동시 처리수 
#define MAX_THREAD 16

// 쓰레드 함수 외부 선언
extern void* threadReciever(void* arg);

pthread_mutex_t mutx;
int client_socket[MAX_THREAD];
int client_number = 0;

// 소켓통신 서버 시작
int startServer(struct sockaddr_in* server_addr, int* s_fd, int port) {

	if( ((*s_fd) = socket( AF_INET, SOCK_STREAM, 0)) == -1 ){		
		printf("ERROR OPEN SOCKET\n");
		return -1;
	}

	memset(server_addr, 0x00, sizeof(*server_addr));	
	(*server_addr).sin_family = AF_INET;
	(*server_addr).sin_addr.s_addr = htonl(INADDR_ANY);
	(*server_addr).sin_port = htons(port);

	if( bind(*s_fd, (struct sockaddr*)server_addr, sizeof(*server_addr)) < 0 ){
		printf("ERROR CAN NOT BIND\n");
		return -1;
	} 

	if( listen(*s_fd, 5) < 0 ){
		printf("ERROR CAN NOT LISTEN CONNECT\n");
		return -1;
	}

	return 1;
}

int main(int argc, char const *argv[]) {

	// 프로그램 실행시 사용할 포트번호 지정
	if(argc < 2) {
		printf("Need to Setting PORT NUMBER!");
		return -1;
	}
	int port = atoi(argv[1]);
		
	// 소켓 통신용 변수
	struct sockaddr_in server_addr, client_addr;
	int s_fd, c_fd;
	int len = sizeof(client_addr);

	FILE *fp;

	// 쓰레드 시작
	pthread_t thread;
	if(pthread_mutex_init(&mutx, NULL)) {
		printf("ERROR : INIT THREAD");
		return -1;
	}

	// 소켓 통신 시작
	if ( startServer(&server_addr, &s_fd, port) )
		printf("START SERVER!\n");
	else
		return -1;

	while(1) {
		c_fd = accept( s_fd, (struct sockaddr *)&client_addr, (socklen_t*) &len );
		if(c_fd < 0){
			printf("ERROR : ACCEPT FAILED\n");
			return -1;
		}
		printf("CONNECT!\n");

		pthread_mutex_lock(&mutx);
		client_socket[client_number++] = c_fd;
		pthread_mutex_unlock(&mutx);		

		// 클라이언트 연결되면 클라이언트 연결 정보를 넘겨주면서 
		// threadReciever 함수를 thread로 실행 -> 동시에 다중 처리 가능
		pthread_create(&thread, NULL, threadReciever, (void*)c_fd);
	}

	return 0;
}
