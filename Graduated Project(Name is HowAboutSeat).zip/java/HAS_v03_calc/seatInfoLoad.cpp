#include "headers.hpp"

#define DBHOST "porori92.iptime.org"
#define DBPORT 6606
#define DBUSER "dbuser"
#define DBPASS "1234"
#define DBNAME "dbserver"

#define BUFFSIZE 1024

typedef struct _seat Seat;
typedef struct _dbinfo DBInfo;

Seat* seatInfoLoad(char* pcname, int* refX, int* refY, int* numSeat){
	MYSQL *mysql;
	MYSQL_RES *result;
	MYSQL_ROW row;
	int field_cnt;	

	unsigned long *length;
	char query[BUFFSIZE];

	mysql = mysql_init(NULL);

	if( !mysql_real_connect(mysql, DBHOST, DBUSER, DBPASS, DBNAME, DBPORT, NULL, 0) ) {
		printf("MYSQL ERROR!\n");
		return NULL;
	}

	sprintf(query, "select refimg, totalseat, refX, refY from pcroom_list where pcname = '%s'", pcname);
	if( mysql_query(mysql, query) ){
		fprintf(stderr, "%s\n", mysql_error(mysql));
		printf("ERROR!");
		return NULL;
	}
	
	result = mysql_store_result(mysql);
	row = mysql_fetch_row(result);
	length = mysql_fetch_lengths(result);
	
	char filename[64];
	strcpy(filename, pcname);
	const char* str2 = "_ref.png";
	strcat(filename, str2);

	FILE *fp = fopen(filename, "wb");
	fwrite(row[0], length[0], 1, fp);	
	fclose(fp);

	*numSeat = atoi(row[1]);
	*refX = atoi(row[2]);
	*refY = atoi(row[3]);
	
	printf("seat = %d\n", atoi(row[1]));	
	Seat* seats = (Seat*) malloc(sizeof(Seat) * (*numSeat));

	mysql_free_result(result);

	memset(query, 0 ,BUFFSIZE);
	sprintf(query, "select seatnum, locX, locY from %s", pcname);
	if( mysql_query(mysql, query) ){
		fprintf(stderr, "%s\n", mysql_error(mysql));
		printf("ERROR!");
		return NULL;
	}

	result = mysql_store_result(mysql);
	int i = 0;
	while( row = mysql_fetch_row(result) ){
		seats[i].seatnum = atoi(row[0]);
		seats[i].locX = atoi(row[1]);
		seats[i].locY = atoi(row[2]);
		seats[i].empty = 'N';
		i++;
	}
	mysql_free_result(result);

	mysql_close(mysql);	

	return seats;
}