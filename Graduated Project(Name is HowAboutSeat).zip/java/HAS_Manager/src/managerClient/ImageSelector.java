package managerClient;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

class ImageSelector {
	Dimension des = new Dimension();
	BufferedImage imgt;
	ArrayList<int[]> vt = new ArrayList<int[]>();

	Rectangle rect = null;
	static boolean startFlag = false;
	JButton btnSave = new JButton("저장");

	ImageSelector(String name, File file, int seat, int resX, int resY, PCInfoDAO info){
		
		int x = 0; int y = 0;		
				
		// 이미지 불러오기
		try {
			imgt = ImageIO.read(file);
			x = imgt.getWidth();
			y = imgt.getHeight();
			des.setSize(x, y);
			rect = new Rectangle(des);
		}
		catch(IOException e){
			e.printStackTrace();
		}

		// 프레임 기본 생성
		JFrame fr = new JFrame();		
		fr.setSize(x+300, y);
		Container ct = fr.getContentPane();
		ct.setLayout(null);

		// 마우스 따라다니는 패널 생성
		JPanel pnBox = new JPanel();
		pnBox.setBorder(new LineBorder(Color.RED, 5, true));
		pnBox.setSize(resX, resY);
		pnBox.setOpaque(false);

		// 이미지 백그라운드 패널 생성
		JPanel draw = new JPanel();		
		JLabel lb1 = new JLabel();
		lb1.setIcon(new ImageIcon(imgt));

		draw.setSize(des);
		draw.setLocation(0, 0);
		draw.setLayout(null);
		lb1.setSize(des);
		lb1.setLocation(0, 0);

		draw.addMouseMotionListener(new MouseMotionListener() { // 리스너로 패널 따라다니기
			@Override
			public void mouseDragged(MouseEvent e) {} 
			@Override
			public void mouseMoved(MouseEvent e) {
				pnBox.setLocation(e.getLocationOnScreen());				
			}
		});

		draw.add(pnBox);
		draw.add(lb1);

		ct.add(draw);

		JPanel menu = new JPanel();
		menu.setSize(300, y);
		menu.setLocation(x, 0);
		menu.setLayout(new FlowLayout());

		JButton btn1 = new JButton("빈자리 선택");
		DefaultSelector df = new DefaultSelector(draw, resX, resY, imgt);
		SeatSelector ss = new SeatSelector(draw, rect, lb1, seat, vt);

		btn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "빈자리를 선택해주세요.", "안내", JOptionPane.INFORMATION_MESSAGE);
				draw.removeMouseListener(ss);
				draw.addMouseListener(df);
			}			
		});
		menu.add(btn1);

		JButton btn2 = new JButton("전체 자리 선택");
		btn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(startFlag == false) {
					JOptionPane.showMessageDialog(null, "빈자리부터 선택해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
					return;
				}
				JOptionPane.showMessageDialog(null, "전체 자리를 선택해주세요.", "안내", JOptionPane.INFORMATION_MESSAGE);
				draw.removeMouseListener(df);
				draw.addMouseListener(ss);
				btnSave.setEnabled(true);
			}
		});
		menu.add(btn2);
		
		btnSave.setEnabled(false);
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(JOptionPane.showConfirmDialog(null, "저장하시겠습니까?") == JOptionPane.OK_OPTION) {
					
					// DBServer 업데이트
					DBServer dbs = new DBServer();
					dbs.newPCRoom(name, vt, resX, resY, info);
					dbs.close();
					
					// Main DB 업데이트 필요
					MainDB db = new MainDB();
					db.updatePCRoom(name);
					db.close();					
					
					JOptionPane.showMessageDialog(null, "저장되었습니다!", "안내", JOptionPane.INFORMATION_MESSAGE);

					fr.dispose();
					new PCRoomList();
				}
			}			
		});
		
		menu.add(btnSave);
		
		/*
		menu.add(lbExp);
		menu.add(scExp);
		*/
		
		ct.add(menu);

		fr.setUndecorated(true);
		fr.setVisible(true);
		fr.setResizable(false);
		fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}

class DefaultSelector implements MouseListener{

	JPanel draw;
	int resX, resY;
	BufferedImage img;
		

	DefaultSelector(JPanel draw, int resX, int resY, BufferedImage src){
		this.draw = draw;
		this.resX = resX;
		this.resY = resY;
		this.img = src;
	}

	@Override
	public void mouseClicked(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		
		try {
			BufferedImage temp = new BufferedImage(resX, resY, BufferedImage.TYPE_INT_BGR);
			temp.createGraphics().drawImage(img, 0, 0, resX, resY, x, y, x+resX, y+resY, null);
			ImageIO.write(temp, "png", new File("temp2.dat"));
		} catch (Exception e1) { e1.printStackTrace(); }
		
		JOptionPane.showMessageDialog(null, "빈자리가 선택되었습니다!", "알림", JOptionPane.INFORMATION_MESSAGE);
		draw.removeMouseListener(this);
		ImageSelector.startFlag = true;
		return;		
	}

	@Override
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {}
	@Override
	public void mouseExited(MouseEvent e) {}

}

class SeatSelector implements MouseListener {
	JPanel draw;
	Rectangle rect = null;
	JLabel lb1;
	int seat;
	int i = 0;
	ArrayList<int[]> vt;

	SeatSelector(JPanel draw, Rectangle rect, JLabel lb1, int seat, ArrayList<int[]> vt) {
		this.draw = draw;
		this.rect = rect;
		this.lb1 = lb1;
		this.seat = seat;
		this.vt = vt;
	}

	public void mousePressed(MouseEvent e) {
		if(i < seat) { // 첫 클릭이 아닐시 좌석 수 만큼 배열에 임시저장
			try {
				Robot robot = new Robot();
				BufferedImage temp = robot.createScreenCapture(rect);
				lb1.setIcon(new ImageIcon(temp));
			} 
			catch (AWTException e1) {
				e1.printStackTrace();
			}

			int xy[] = { e.getX(), e.getY() };
			vt.add(xy);
			i++;
			if(i == seat) {
				JOptionPane.showMessageDialog(null, "자리 지정이 끝났습니다!", "오류", JOptionPane.ERROR_MESSAGE);
				draw.removeMouseListener(this);
			}
			return;
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {}
	@Override
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {}
	@Override
	public void mouseExited(MouseEvent e) {}
}
