package managerClient;

import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ExeServerAdd {

	GridBagLayout gbag = new GridBagLayout();
	JButton btn1 = new JButton("테스트");
	JButton btn2 = new JButton("저장");
	JButton btn3 = new JButton("취소");
	JLabel lbName = new JLabel("이름 : ");
	JTextField fdName = new JTextField(15);

	JLabel lbAddr = new JLabel("서버 주소 : ");
	JTextField fdAddr = new JTextField(15);

	JLabel lbPort = new JLabel("포트 : ");
	JTextField fdPort = new JTextField(15);

	ExeServerAdd() {	
		JFrame fr = new JFrame();
		fr.setSize(300, 150);
		fr.setTitle("Server Add");
		fr.setResizable(false);

		Container ct = fr.getContentPane();
		ct.setLayout(new FlowLayout());

		JPanel pn1 = new JPanel();
		pn1.setLayout(gbag);

		gbinsert(lbName, 0, 0, 1, 1, pn1);
		gbinsert(fdName, 1, 0, 3, 1, pn1);
		gbinsert(lbAddr, 0, 1, 1, 1, pn1);
		gbinsert(fdAddr, 1, 1, 3, 1, pn1);
		gbinsert(lbPort, 0, 2, 1, 1, pn1);
		gbinsert(fdPort, 1, 2, 3, 1, pn1);

		ct.add(pn1);

		btn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String addr = fdAddr.getText();
					int port = Integer.parseInt(fdPort.getText());
					
					ExeServerTest test = new ExeServerTest(addr, port);

					if(test.doTest()) {
						btn2.setEnabled(true);
						fdName.setEditable(false);
						fdAddr.setEditable(false);
						fdPort.setEditable(false);
						JOptionPane.showMessageDialog(null, "테스트 성공하였습니다.", "테스트 결과", JOptionPane.INFORMATION_MESSAGE);
					}
					else {
						JOptionPane.showMessageDialog(null, "테스트 실패하였습니다.", "테스트 결과", JOptionPane.ERROR_MESSAGE);
					}
				} catch(Exception ee) {
					JOptionPane.showMessageDialog(null, "테스트 실패하였습니다.", "테스트 결과", JOptionPane.ERROR_MESSAGE);
				}
			}
		});


		btn2.setEnabled(false);
		btn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if( JOptionPane.showConfirmDialog(null, "저장하시겠습니까?") == JOptionPane.OK_OPTION ) {
					MainDB db = new MainDB();
					db.addExeServer(fdName.getText(), fdAddr.getText(), fdPort.getText());
					db.close();
					
					JOptionPane.showMessageDialog(null, "저장되었습니다!", "확인", JOptionPane.INFORMATION_MESSAGE);
					fr.dispose();
					new ExeServerList();
				}
			}	
		});

		btn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				fr.dispose();	
				new ExeServerList();
			}			
		});

		ct.add(btn1);
		ct.add(btn2);
		ct.add(btn3);

		fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		fr.setVisible(true);
	}

	public void gbinsert(Component c, int x, int y, int w, int h, Container ct){
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill= GridBagConstraints.BOTH;
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.gridwidth = w;
		gbc.gridheight = h;
		gbag.setConstraints(c, gbc);

		ct.add(c);
	}


}
