package managerClient;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class ExeServerTest {

	private static final int STRING_SIZE = 64;
	Socket socket = null;
	
	ExeServerTest(String addr, int port) {

		try {
			socket = new Socket(addr, port);
			
		} catch (IOException e) { e.printStackTrace(); }


	}
	
	boolean doTest() {

		boolean result = false;
		
		OutputStream os;
		try {	
			os = socket.getOutputStream();
			ByteBuffer buffer = null;
			
			buffer = ByteBuffer.allocate(STRING_SIZE);
			buffer.order(ByteOrder.LITTLE_ENDIAN);
			
			String msg = "Test Server";
			
			buffer.put(msg.getBytes());
			buffer.put(new byte[STRING_SIZE - msg.getBytes().length]);
			os.write(buffer.array());
			os.flush();
			
			BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
			
			byte[] buff = new byte[STRING_SIZE];
			bis.read(buff, 0, STRING_SIZE);
			String temp = new String(buff);
			
			if(temp.contains(msg)) {
				result = true;
			}
			
			os.close();
			socket.close();
			
			return result;
			
		} catch (IOException e) { e.printStackTrace(); return result; }		
	}

}
