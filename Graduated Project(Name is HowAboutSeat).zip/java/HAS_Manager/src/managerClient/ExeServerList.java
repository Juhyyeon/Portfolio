package managerClient;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class ExeServerList {
	ExeServerList(){
		
		JFrame fr = new JFrame();
		fr.setSize(500, 300);
		fr.setTitle("Server Manage");
		fr.setResizable(false);
		
		Container ct = fr.getContentPane();
		ct.setLayout(new BorderLayout());
		
		MainDB db = new MainDB();
		ArrayList<String[]> server = db.getExeServer();
		
		String[] title = {"서버 이름", "주소", "포트"};
		String[][] contents = new String[server.size()][3];
		
		for(int i=0; i<contents.length; i++) {
			contents[i] = server.get(i);
		}
		

		JTable table = new JTable();
		table.setModel(new DefaultTableModel(contents, title) {
			private static final long serialVersionUID = 1L; // what?
			public boolean isCellEditable(int row, int col) {
				return false;
			}
		});
		
		table.getTableHeader().setReorderingAllowed(false);
		table.getTableHeader().setResizingAllowed(false);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		JScrollPane scroll = new JScrollPane(table);
		ct.add(scroll);
		
		JPanel panelBtn = new JPanel();
		panelBtn.setLayout(new GridLayout(2, 1, 10, 10));
		JButton btnSetup = new JButton("추가");
		btnSetup.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					new ExeServerAdd();
					fr.dispose();
				} catch(Exception ee) {
					ee.printStackTrace();
				}
				
			}
		}); panelBtn.add(btnSetup);
		
		JButton btnDelete = new JButton("삭제");
		btnDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String temp = null;
				try {
					temp = contents[table.getSelectedRow()][0];
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "연산서버를 선택해 주세요!", "오류", JOptionPane.ERROR_MESSAGE);
				}
				
				if(temp != null) {
					if( JOptionPane.showConfirmDialog(null, "정말 삭제하시겠습니까?") == JOptionPane.OK_OPTION ) {
						MainDB db = new MainDB();
						db.deleteExeServer(temp);
						db.close();
						JOptionPane.showMessageDialog(null, "삭제되었습니다!", null, JOptionPane.INFORMATION_MESSAGE);
						fr.dispose();
						new ExeServerList();
					}
				}
			}
			
		}); panelBtn.add(btnDelete);
		
		ct.add(panelBtn, BorderLayout.EAST);
	
		fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		fr.setVisible(true);
	}
}
