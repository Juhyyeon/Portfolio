package managerClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DBServer {
	private final String jdbc = "org.mariadb.jdbc.Driver";
	private final String url = "jdbc:mariadb://porori92.iptime.org:6606/dbserver";
	private final String userID = "dbuser";
	private final String userPW = "1234";
		
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	DBServer() {
		try {
			Class.forName(jdbc);
			conn = DriverManager.getConnection(url, userID, userPW);
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	void newPCRoom(String name, ArrayList<int[]> vt, int resX, int resY, PCInfoDAO info) {
		
		try {		
			String query = "create table "+name+"("
					+ "seatnum int,"
					+ "locX int,"
					+ "locY int,"
					+ "empty char NULL DEFAULT 'N')";
			
			pstmt = conn.prepareStatement(query);
			pstmt.executeUpdate();
			pstmt.close();
			
			query = "insert into "+name+"(seatnum, locX, locY) values (?, ?, ?)";
			pstmt = conn.prepareStatement(query);
			
			int[] temp;
			for(int i=0; i<vt.size(); i++) {
				temp = vt.get(i);
				pstmt.setInt(1, i+1);
				pstmt.setInt(2, temp[0]);
				pstmt.setInt(3, temp[1]);
				pstmt.executeUpdate();
			}
			
			pstmt.close();
			
			query = "insert into pcroom_list(pcname, totalseat, refimg, refX, refY, geoX, geoY, korname, addr, exptext) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setInt(2, vt.size());
			pstmt.setBlob(3, new FileInputStream(new File("temp2.dat")));
			pstmt.setInt(4, resX);
			pstmt.setInt(5, resY);
			pstmt.setDouble(6, info.getGeoX());
			pstmt.setDouble(7, info.getGeoY());
			pstmt.setString(8, info.getKorname());
			pstmt.setString(9, info.getAddr());
			pstmt.setString(10, info.getExptext());
			
			pstmt.executeUpdate();
			
		} catch (SQLException | FileNotFoundException e) { e.printStackTrace(); }
	}
	
	void newPCInfo(PCInfoDAO info) {
		String query = "insert into pcroom_info(pcname, korname, addr, exptext) values (?, ?, ?, ?)";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, info.getPcname());
			pstmt.setString(2, info.getKorname());
			pstmt.setString(3, info.getAddr());
			pstmt.setString(4, info.getExptext());
			pstmt.executeUpdate();
			
		} catch (SQLException e) { e.printStackTrace(); }
		
	}
	
	void deletePCRoom(String name) {
		try {
			String query = "drop table if exists "+name;
			pstmt = conn.prepareStatement(query);
			pstmt.executeUpdate();
			pstmt.close();
			
			query = "delete from pcroom_list where pcname like ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.executeUpdate();			
			pstmt.close();
			
			query = "delete from pcroom_info where pcname like ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.executeUpdate();
			
		} catch (SQLException e) { e.printStackTrace(); }
		
	}
	
	void close() {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
