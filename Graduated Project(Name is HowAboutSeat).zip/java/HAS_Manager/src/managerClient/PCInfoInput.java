package managerClient;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URLEncoder;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class PCInfoInput {
	
	private PCInfoDAO info;
	
	
	PCInfoInput(PCInfoDAO info) {
		this.info = info;
	}
	
	public void makeFrame() {
		JFrame fr = new JFrame();
		fr.setTitle("시설 정보 입력");
		fr.setSize(500, 400);
		
		Container ct = fr.getContentPane();
		ct.setLayout(new GridLayout(6, 1, 10, 10));
		
		JPanel pn1 = new JPanel();
		JLabel lbName = new JLabel("관리 이름 : ");
		JTextField fdName = new JTextField(8);
		fdName.setText(info.getPcname());
		fdName.setEditable(false);
		pn1.add(lbName);
		pn1.add(fdName);
		
		JPanel pn2 = new JPanel();
		JLabel lbKorName = new JLabel("표시 이름 : ");
		JTextField fdKorName = new JTextField(8);
		pn2.add(lbKorName);
		pn2.add(fdKorName);

		JPanel pn3 = new JPanel();
		JLabel lbAddr = new JLabel("주소");
		JTextField fdAddr = new JTextField(30);
		JButton btnAddr = new JButton("좌표 찾기");
		btnAddr.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					new ProcessBuilder("cmd", "/c", "start", "iexplore", "https://www.google.com/maps/search/"+URLEncoder.encode(fdAddr.getText(), "UTF-8")).start();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		pn3.add(lbAddr);
		pn3.add(fdAddr);
		pn3.add(btnAddr);
		
		JPanel pn4 = new JPanel();
		JLabel lbGeoX = new JLabel("좌표 위도 : ");
		JTextField fdGeoX = new JTextField(8);
		JLabel lbGeoY = new JLabel("좌표 경도 : ");
		JTextField fdGeoY = new JTextField(8);
		pn4.add(lbGeoX);
		pn4.add(fdGeoX);
		pn4.add(lbGeoY);
		pn4.add(fdGeoY);
		
		JPanel pn5 = new JPanel(new BorderLayout());
		JLabel lbExpText = new JLabel("설명 : ");
		JTextArea arExpText = new JTextArea();
		JScrollPane scExpText = new JScrollPane(arExpText);
		pn5.add(lbExpText, BorderLayout.WEST);
		pn5.add(scExpText, BorderLayout.CENTER);
		
		JPanel pn6 = new JPanel();
		JButton btnSave = new JButton("저장");
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				String tempKorName = fdKorName.getText();
				String tempAddr = fdAddr.getText();
				String tempGeoX = fdGeoX.getText();
				String tempGeoY = fdGeoY.getText();
				String tempExpT = arExpText.getText();
				
				double tempX, tempY;
				
				if(tempKorName.length() == 0 || tempAddr.length() == 0 || tempGeoX.length() == 0 || tempGeoY.length() == 0 || tempExpT.length() == 0) {
					JOptionPane.showMessageDialog(null, "값을 모두 입력해주세요!", "에러", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				try {
					tempX = Double.parseDouble(tempGeoX);
					tempY = Double.parseDouble(tempGeoY);
				} catch(Exception ee) {
					JOptionPane.showMessageDialog(null, "올바른 좌표값을 입력해주세요!", "에러", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if(JOptionPane.showConfirmDialog(null, "저장하시겠습니까?") == JOptionPane.OK_OPTION) {
					info.setAddr(tempAddr);
					info.setKorname(tempKorName);
					info.setGeoX(tempX);
					info.setGeoY(tempY);
					info.setExptext(tempExpT);
					
					JOptionPane.showMessageDialog(null, "저장되었습니다!", "알림", JOptionPane.INFORMATION_MESSAGE);
					fr.dispose();
				}
				
				
				
			}
			
		});
		pn6.add(btnSave);
		
		
		ct.add(pn1);
		ct.add(pn2);
		ct.add(pn3);
		ct.add(pn4);
		ct.add(pn5);
		ct.add(pn6);
		
		
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}

}

	