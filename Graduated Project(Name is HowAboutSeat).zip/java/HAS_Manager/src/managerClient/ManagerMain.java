package managerClient;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ManagerMain {

	ManagerMain() {
		MainDB db = new MainDB();
		
		JFrame fr = new JFrame();
		fr.setTitle("How About Seat? Manager");
		fr.setSize(300, 250);
		fr.setResizable(false);
		
		Container ct = fr.getContentPane();
		ct.setLayout(new GridLayout(4, 2, 40, 30));
		
		JLabel labelPC = new JLabel("등록된 시설 : ");
		JLabel labelPCcnt = new JLabel("0 개");		
		labelPCcnt.setText(Integer.toString(db.getPCRoomNum()) + " 개");	
		ct.add(labelPC);
		ct.add(labelPCcnt);
		
		JLabel labelEXE = new JLabel("등록된 연산서버 : ");
		JLabel labelEXEcnt = new JLabel("0 개");
		labelEXEcnt.setText(Integer.toString(db.getExeServerCnt())+ " 개");
		ct.add(labelEXE);
		ct.add(labelEXEcnt);
		
		JLabel labelERROR = new JLabel("발생된 오류 : ");
		JLabel labelERRORcnt = new JLabel("0 개");
		// ERROR CNT		
		ct.add(labelERROR);
		ct.add(labelERRORcnt);
		
		JButton btnPC = new JButton("시설 관리");
		JButton btnEXE = new JButton("연산서버 관리");
		
		btnPC.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new PCRoomList();
			}
		});
		
		btnEXE.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new ExeServerList();
			}
		});
		
		ct.add(btnPC);
		ct.add(btnEXE);
		
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fr.setVisible(true);
		db.close();
	}
	
	
	
	
	public static void main(String[] args) {
		new ManagerMain();
	}

}
