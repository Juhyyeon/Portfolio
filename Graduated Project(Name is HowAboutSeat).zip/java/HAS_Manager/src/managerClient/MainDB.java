/*
 * 서버 관리 클라이언트 DBClass
 * url => Main Server
 */

package managerClient;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MainDB {
	
	private final String jdbc = "org.mariadb.jdbc.Driver";
	private final String url = "jdbc:mariadb://porori92.iptime.org:6606/mainserver";
	private final String userID = "test";
	private final String userPW = "1234";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	MainDB() {
		try {
			Class.forName(jdbc);
			conn = DriverManager.getConnection(url, userID, userPW);
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public ArrayList<String[]> getPCRoom() {
		String query = "select pcname, care from pcroom";
		ArrayList<String[]> list = new ArrayList<String[]>();
		try {
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String[] temp = { rs.getString(1), rs.getString(2) };
				list.add(temp);
			}
			return list;
		} catch (SQLException e) { e.printStackTrace(); return null; }
	}
	
	public int getPCRoomNum() {
		String query = "select count(pcname) from pcroom";
		try {
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			rs.next(); return rs.getInt(1);		
		} catch (SQLException e) { e.printStackTrace();	return 0; }	
	}
	
	public void updatePCRoom(String name) {
		String query = "update pcroom set care = 1 where pcname like ?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
	}
	
	public void deletePCRoom(String name) {
		String query = "delete from pcroom where pcname like ?";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
	}
	
	
	// EXESERVER 메소드
	

	public int getExeServerCnt() {
		String query = "select count(name) from exeserver";		
		try {
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			rs.next(); return rs.getInt(1); 
		} catch (SQLException e) { e.printStackTrace(); return 0; }
	}
	
	public ArrayList<String[]> getExeServer() {
		String query = "select name, address, port from exeserver";
		ArrayList<String[]> list = new ArrayList<String[]>();
		
		try {
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String[] temp = { rs.getString(1), rs.getString(2), rs.getString(3) };
				list.add(temp);
			}
			return list;
		} catch (SQLException e) { e.printStackTrace(); return null;}
	}
	
	public void addExeServer(String name, String addr, String port) {
		String query = "insert into exeserver(name, address, port) values(?, ?, ?)";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setString(2, addr);
			pstmt.setString(3, port);
			
			pstmt.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
		
	}
	
	public void deleteExeServer(String name) {
		String query = "delete from exeserver where name like ?";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.executeUpdate();
		} catch (SQLException e) { e.printStackTrace();	}		
	}
	
	public void close() {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			conn.close();
		} catch (SQLException e) { e.printStackTrace(); }
	}
	
}