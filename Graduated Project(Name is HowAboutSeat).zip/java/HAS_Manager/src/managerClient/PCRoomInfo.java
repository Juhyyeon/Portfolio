package managerClient;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PCRoomInfo {

	File file;
	Image imgSrc;
	
	JFrame fr = new JFrame();
	Container ct_main = fr.getContentPane();
	
	JPanel pn_left = new JPanel();
	JPanel pn_right = new JPanel();	
	
	JLabel lb_img = new JLabel();
	
	JLabel lbSeat = new JLabel("좌석 수 ");
	JTextField numSeat = new JTextField(4);

	JLabel lbResX = new JLabel("좌석 크기 X ");
	JTextField numResX = new JTextField(4);
	JLabel lbResY = new JLabel("좌석 크기 Y ");
	JTextField numResY = new JTextField(4);
	
	JButton btnStart = new JButton("이미지 설정");
	
	PCInfoDAO info;
	
	boolean startFlag = false;
	
	PCRoomInfo(String selectName){
		info = new PCInfoDAO(selectName);
		
		fr.setSize(890, 640);
		fr.setTitle("이미지 설정_v8");
		fr.setResizable(false);
		
		ct_main.setLayout(null);

		pn_left.setSize(640, 640);
		pn_right.setSize(250, 640);
		pn_left.setLocation(0, 0);
		pn_right.setLocation(640, 0);

		pn_left.setLayout(new BorderLayout());
		pn_right.setLayout(new GridLayout(8, 1, 10, 10));

		// 이미지 미리보기 라벨
		pn_left.add(lb_img, BorderLayout.CENTER);
		
		ServerConnector sc = new ServerConnector();
		file = sc.recieveFile(selectName);
		sc.close();
		
		try {
			imgSrc = ImageIO.read(file);
			BufferedImage resize = resizeImage(imgSrc);
			ImageIcon img = new ImageIcon(resize);
			lb_img.setIcon(img);
		} catch (IOException e) { e.printStackTrace(); }
		
		// 좌석 수 입력
		JPanel r2 = new JPanel(new FlowLayout());
		r2.add(lbSeat);
		r2.add(numSeat);
		pn_right.add(r2);
		
		// 좌석 크기 입력
		JPanel r3 = new JPanel(new FlowLayout());
		r3.add(lbResX);
		r3.add(numResX);
		pn_right.add(r3);
		JPanel r4 = new JPanel(new FlowLayout());
		r4.add(lbResY);
		r4.add(numResY);
		pn_right.add(r4);
		
		// 피시방 설정
		JPanel r5 = new JPanel();
		JButton btnExp = new JButton("정보 입력");
		btnExp.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PCInfoInput input = new PCInfoInput(info);
				input.makeFrame();
			}
		});
		r5.add(btnExp);
		pn_right.add(r5);
	
		// 이미지 설정		
		btnStart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int seat;
				String temp = numSeat.getText();
				if(temp.equals("")) {
					JOptionPane.showMessageDialog(null, "좌석 수를 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				int resX; int resY;
				String tempX = numResX.getText();
				String tempY = numResY.getText();

				if(tempX.equals("") || tempY.equals("")) {
					JOptionPane.showMessageDialog(null, "좌석 크기를 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if(info.getAddr() == null) {
					JOptionPane.showMessageDialog(null, "시설 정보를 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				try {
					seat = Integer.parseInt(temp);
					resX = Integer.parseInt(tempX);
					resY = Integer.parseInt(tempY);
				}
				catch(NumberFormatException ee) {
					JOptionPane.showMessageDialog(null, "숫자만 입력하세요.", "오류", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
			
				new ImageSelector(selectName, file, seat, resX, resY, info); // 이미지 설정용 새 프레임 객체
				fr.dispose();
			}
		});
		
		pn_right.add(btnStart);
		
		
		
		
		ct_main.add(pn_left);
		ct_main.add(pn_right);

		fr.setVisible(true);
		fr.setResizable(false);
		fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	// 리사이즈 이미지 메소드
	BufferedImage resizeImage(Image image){
		// 리사이즈 될 이미지 해상도 지정
		final int IMG_WIDTH = 640;
		final int IMG_HEIGHT = 360;

		BufferedImage temp = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_RGB);
		temp.getGraphics().drawImage(image.getScaledInstance(IMG_WIDTH, IMG_HEIGHT, Image.SCALE_SMOOTH), 0, 0, null);		

		return temp;
	}
	
}
