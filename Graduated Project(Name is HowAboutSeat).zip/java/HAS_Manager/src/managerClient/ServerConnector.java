package managerClient;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ServerConnector {
	final String host = "porori92.iptime.org";
	final int port = 9002;
	
	Socket socket = null;
	OutputStream os = null;
	DataOutputStream dos = null;
	
	ServerConnector() {
		try {
			socket = new Socket(host, port);
		} catch (IOException e) { e.printStackTrace(); }
	}
	
	File recieveFile(String name) {
		File f = new File("temp.dat");
		
		try {
			os = socket.getOutputStream();
			dos = new DataOutputStream(os);
			dos.writeUTF(name);
			
			InputStream is = socket.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			FileOutputStream fos = new FileOutputStream(f);
			
			byte[] buffer = new byte[8192];
			int readBytes;
			
			while( (readBytes = is.read(buffer)) != -1 ) {
				fos.write(buffer, 0, readBytes);
			}
			
			fos.close();
			dis.close();
			is.close();
			
			return f;
			
		} catch (IOException e) { e.printStackTrace(); return null; }	
	}
	
	void close() {
		try { os.close(); dos.close(); socket.close(); } catch (IOException e) { e.printStackTrace(); } 
	}
	
}
