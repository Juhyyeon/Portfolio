package managerClient;

public class PCInfoDAO {
	private String pcname;
	private String korname;
	private String addr;
	private String exptext;
	private double geoX;
	private double geoY;
	
	PCInfoDAO(String name) {
		this.pcname = name;
	}
	
	public String getPcname() {
		return pcname;
	}
	
	public String getKorname() {
		return korname;
	}
	public void setKorname(String korname) {
		this.korname = korname;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getExptext() {
		return exptext;
	}
	public void setExptext(String exptext) {
		this.exptext = exptext;
	}

	public double getGeoX() {
		return geoX;
	}

	public void setGeoX(double geoX) {
		this.geoX = geoX;
	}

	public double getGeoY() {
		return geoY;
	}

	public void setGeoY(double geoY) {
		this.geoY = geoY;
	}

}
