package pcroom;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CaptureTray {
	
	SystemTray menuTray;
	PopupMenu myPopup;
	MenuItem Exit;
	MenuItem Setup;
	
	CaptureTray(JFrame fr) {
		if(SystemTray.isSupported()) {
			myPopup = new PopupMenu();
			Setup = new MenuItem("Setting...");
			
			Setup.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					fr.setVisible(true);
				}
			});
			
			Exit = new MenuItem("Exit");
			Exit.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			
			myPopup.add(Setup);
			myPopup.add(Exit);
			
			
			Image image = Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("icon.png")); //최소화되었을때 트레이에 보여질 아이콘의 경로 설정
			TrayIcon trayIcon = new TrayIcon(image, "자리어때?", myPopup); //최소화된 아이콘에 커서를 댔을 때 나올 이름과 보여질 아이콘과 팝 메뉴를 인자로 객체 생성
			trayIcon.setImageAutoSize(true);
			
			menuTray = SystemTray.getSystemTray();
			try {
				menuTray.add(trayIcon);
			} catch (AWTException e) { 
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "에러", "에러", JOptionPane.ERROR_MESSAGE);
				System.exit(1);
			}
		}
	}
	

}
