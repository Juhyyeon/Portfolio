package pcroom;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;

public class CaptureThread {
	CaptureThread(String pcname, String addr, int period, TimerTask termTask, Timer term) {
		
		try {
			Robot robot = new Robot();
			File f = new File("temp.dat");
			BufferedImage captureImage = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			ImageIO.write(captureImage, "png", f);				
			
			new FileSender(pcname, addr);
			
		} catch (Exception e) { e.printStackTrace();	}
	}
	
}
