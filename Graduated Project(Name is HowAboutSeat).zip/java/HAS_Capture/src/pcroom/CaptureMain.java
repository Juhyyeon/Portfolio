package pcroom;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class CaptureMain {
	
	private static final String temphost = "porori92.iptime.org";

	Timer term = new Timer();
	TimerTask termTask = null;
	
	
	
	private static final String[] timeText = { "1 분", "3 분", "5 분", "테스트" };
	// timeText의 첫 숫자로 시간 조절하므로 주기 변경시 여기서 숫자 변경할 것!
	
	
	CaptureMain() {
		
		JFrame fr = new JFrame("How About Seat? Capture");
		fr.setSize(400, 400);
		
		Container ct = fr.getContentPane();
		ct.setLayout(new GridLayout(4, 1));
		
		JPanel ip = new JPanel();
		ip.setLayout(new GridLayout(2,1));
		JLabel ipLabel = new JLabel("등록하실 서버의 IP/Domain 입력.");
		ip.add(ipLabel);
		JTextArea ipArea = new JTextArea(1,20);
		ip.add(ipArea);
		ipArea.setText(temphost);
		
		JPanel time = new JPanel();
		time.setLayout(new GridLayout(2, 1));
		
		 
		JComboBox<String> timeBox = new JComboBox<String>(timeText);
		timeBox.setSize(200,30);
		JLabel timeLabel = new JLabel("캡처 주기를 설정하세요");
		time.add(timeLabel);
		time.add(timeBox);
		
		JPanel roomName = new JPanel();
		roomName.setLayout(new GridLayout(2,1));
		JLabel nameLabel = new JLabel("시설의 이름을 입력해주세요");
		JTextArea nameArea = new JTextArea(1,20);
		roomName.add(nameLabel);
		roomName.add(nameArea);
		
		JPanel buttons = new JPanel();
		JButton submit = new JButton("저장");
		submit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(termTask != null) {
					termTask.cancel();
					term.purge();
				}
				
				String pcname = nameArea.getText();
				String addr = ipArea.getText();
				
				String timeTemp = (String) timeBox.getSelectedItem();
				int period = Integer.parseInt(timeTemp.substring(0, 1));
				
				termTask = new TimerTask() {
					@Override
					public void run() {
						new CaptureThread(pcname, addr, period, termTask, term);
					}
				};
					
				// 테스트용
				if(timeTemp.equals("테스트")) {
					term.schedule(termTask, 5, 1000 * 5);
					fr.setVisible(false);
					return;
				}
			
				term.schedule(termTask, 5, 1000 * 60 * period);
				fr.setVisible(false);
			}
		});
		
		JButton cancel = new JButton("취소");
		cancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
		buttons.add(submit);
		buttons.add(cancel);	

		ct.add(ip);
		ct.add(time);
		ct.add(roomName);
		ct.add(buttons);
		
		new CaptureTray(fr);
		
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
	
	public static void main(String[] args) {
		new CaptureMain();
	}

}
