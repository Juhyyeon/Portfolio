CREATE DATABASE  IF NOT EXISTS `test1` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `test1`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: test1
-- ------------------------------------------------------
-- Server version	5.6.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `buy_list`
--

DROP TABLE IF EXISTS `buy_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buy_list` (
  `imgsrc` varchar(1000) NOT NULL,
  `tname` varchar(60) NOT NULL,
  `price` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `result_price` int(11) NOT NULL DEFAULT '0',
  `seller` varchar(100) NOT NULL,
  `id` varchar(60) NOT NULL,
  `pageNum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buy_list`
--

/*!40000 ALTER TABLE `buy_list` DISABLE KEYS */;
INSERT INTO `buy_list` VALUES ('%B5%F0%C1%EE%B4Ϲ%E8%B0%E6ȭ%B8%E9%B0%EDȭ%C1%FA.jpg','포토샵',3300,1,3300,'west00000','minwoo',4),('%B5%F0%C1%EE%B4Ϲ%E8%B0%E6ȭ%B8%E9%B0%EDȭ%C1%FA.jpg','포토샵',3300,20,66000,'west00000','minwoo',4),('%B5%F0%C1%EE%B4Ϲ%E8%B0%E6ȭ%B8%E9%B0%EDȭ%C1%FA.jpg','포토샵',3300,1,3300,'west00000','minwoo',4),('기타.jpg','기타작곡',20000,1,20000,'minwoo','paniccord',1),('dog2.jpg','수면치료',111111,2,222222,'minwoo','west00000',14),('dona1.jpg','안녕하세요',111,1,111,'minwoo','paniccord',12);
/*!40000 ALTER TABLE `buy_list` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-06 20:24:23
