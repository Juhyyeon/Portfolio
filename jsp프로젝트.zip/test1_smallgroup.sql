CREATE DATABASE  IF NOT EXISTS `test1` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `test1`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: test1
-- ------------------------------------------------------
-- Server version	5.6.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `smallgroup`
--

DROP TABLE IF EXISTS `smallgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smallgroup` (
  `bigcode` int(11) NOT NULL,
  `smallcode` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`bigcode`,`smallcode`),
  CONSTRAINT `fk_small` FOREIGN KEY (`bigcode`) REFERENCES `biggroup` (`bigcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smallgroup`
--

/*!40000 ALTER TABLE `smallgroup` DISABLE KEYS */;
INSERT INTO `smallgroup` VALUES (1,1,'웹디자인'),(1,2,'로고'),(1,3,'포토샵 편집'),(1,4,'일러스트/캐릭터'),(1,5,'3D모델링'),(1,6,'캘리그라피'),(2,1,'영어'),(2,2,'중국어'),(2,3,'일본어'),(2,4,'프랑스어'),(2,5,'러시아어'),(2,6,'스페인어'),(3,1,'프레젠테이션'),(3,2,'워드/타이핑'),(3,3,'교정/편집'),(3,4,'엑셀'),(3,5,'통계/분석'),(3,6,'출판'),(4,1,'영상편집/제작'),(4,2,'나레이션/성우'),(4,3,'작사/작곡'),(4,4,'녹음/편집'),(4,5,'애니메이션'),(4,6,'노래/댄스'),(5,1,'홈페이지/웹개발'),(5,2,'응용프로그래밍'),(5,3,'모바일/앱'),(5,4,'쇼핑몰 관련 개발'),(5,5,'프로그램/소스'),(5,6,'PB/서버'),(6,1,'운세'),(6,2,'컴수리'),(6,3,'상담'),(6,4,'미용'),(6,5,'건강'),(6,6,'핸드메이드');
/*!40000 ALTER TABLE `smallgroup` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-06 20:24:24
