CREATE DATABASE  IF NOT EXISTS `test1` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `test1`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: test1
-- ------------------------------------------------------
-- Server version	5.6.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `page_info`
--

DROP TABLE IF EXISTS `page_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_info` (
  `page_num` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(60) NOT NULL,
  `title` varchar(240) NOT NULL,
  `name` varchar(240) NOT NULL,
  `num` varchar(25) NOT NULL,
  `big` varchar(30) NOT NULL,
  `small` varchar(30) NOT NULL,
  `tType` varchar(60) NOT NULL,
  `price` int(11) NOT NULL,
  `trade` varchar(20) NOT NULL,
  `day` varchar(10) NOT NULL,
  `content` varchar(4500) NOT NULL,
  `imgsrc` varchar(1000) NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `recom` int(11) NOT NULL DEFAULT '0',
  `writeday` varchar(30) NOT NULL,
  PRIMARY KEY (`page_num`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_info`
--

/*!40000 ALTER TABLE `page_info` DISABLE KEYS */;
INSERT INTO `page_info` VALUES (1,'minwoo','123','123','123개','문서작성','프레젠테이션','',123,'직거래','1','123','../img/noimage.png',0,0,'2017년 12월 06일'),(2,'minwoo','124124','1442','1424개','음악영상','영상편집/제작','',244,'직거래','1','14214','dona11.jpg',1,0,'2017년 12월 06일');
/*!40000 ALTER TABLE `page_info` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-06 20:24:26
