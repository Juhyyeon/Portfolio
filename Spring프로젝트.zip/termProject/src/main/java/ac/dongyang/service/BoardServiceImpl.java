package ac.dongyang.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import ac.dongyang.domain.BoardVO;
import ac.dongyang.domain.Criteria;
import ac.dongyang.persistence.BoardDAO;

//�뿬湲곗꽌 DAO 硫붿냼�뱶�뱾�쓣 �샇異쒗븷 寃껋엫(DAO�� 而⑦듃濡ㅻ윭�쓽 以묎컙�떎由� �뿭�븷)
//�꽌鍮꾩뒪 �겢�옒�뒪�뱾�� Service �뼱�끂�뀒�씠�뀡 �븘�슂
//硫붿냼�뱶�쓽 �씠由� �뿭�떆 怨좉컼�씠 �슂援ы븯�뒗��濡� �옉�꽦�빐二쇱뼱�빞�븿
@Service
public class BoardServiceImpl implements BoardService {

	@Inject
		private BoardDAO dao;
	
	@Override
	public void create(BoardVO vo) {
		dao.create(vo);
	}
	
	@Override
	public BoardVO read(int bno) {
		return dao.read(bno);
	}

	@Override
	public void update(BoardVO vo) {
		dao.update(vo);
	}

	@Override
	public void delete(int bno) {
		dao.delete(bno);
	}

	@Override
	public List<BoardVO> listAll() {
		return dao.listAll();
	}

	@Override
	public List<BoardVO> listCriteria(Criteria cri) {
		return dao.listCriteria(cri);
	}

	@Override
	public int getTotalCount() {
		// TODO Auto-generated method stub
		return dao.getTotalCount();	
		}

	@Override
	public int getSearchTotalCount(Criteria cri) {
		// TODO Auto-generated method stub
		return dao.getSearchTotalCount(cri);
	}

	@Override
	public List<BoardVO> listCriteriaS(Criteria cri) {
		// TODO Auto-generated method stub
		return dao.listCriteriaS(cri);
	}

	@Override
	public void increaseHitCount(BoardVO vo) {
		dao.increaseHitCount(vo);
		
	}

	

}
