package ac.dongyang.domain;

//페이징 처리 클래스
public class PageMaker {

	private int startPage;
	private int endPage;
	private boolean prev;
	private boolean next;
	private int totalCount;
	private int displayPageNum=10;
	private Criteria cri;
	public int getStartPage() {
		return startPage;
	}
	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	public boolean isPrev() {
		return prev;
	}
	public void setPrev(boolean prev) {
		this.prev = prev;
	}
	public boolean isNext() {
		return next;
	}
	public void setNext(boolean next) {
		this.next = next;
	}
	public int getTotalCount() {
		return totalCount;
	}
	//totalCount 값이 설정되기 전에 처리를 하게 되면 제대로된 처리가 되지 않기 떄문에 값이 setting 될 때 호출하는 것이 적절함
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
		calcData();
	}
	public int getDisplayPageNum() {
		return displayPageNum;
	}
	public void setDisplayPageNum(int displayPageNum) {
		this.displayPageNum = displayPageNum;
	}
	public Criteria getCri() {
		return cri;
	}
	public void setCri(Criteria cri) {
		this.cri = cri;
	}
	private void calcData()
	{
		//한 화면당 표시되는 마지막 페이지 번호 계산
		endPage = (int) (Math.ceil(cri.getPage()/(double)displayPageNum)*displayPageNum);
		//한 화면당 표시되는 첫 페이지 번호 계산
		startPage = (endPage - displayPageNum) + 1;
		// 맨 마지막 페이지 번호  --> 조건식에 만족할 떄 표시하기 위한 
		int tempEndPage = (int) (Math.ceil(totalCount/(double)cri.getPerPageNum()));
	
		if(endPage>tempEndPage)
		{
			endPage = tempEndPage;
		}
		//이번(prev) 여부 판단 --> 1페이지의 경우 이전으로 돌아갈 수 있는 페이지가 더 이상 없기 떄문임. previous 버튼 비활성화
		prev=startPage==1?false:true;
		
		//다음(next) 야부 판단 --> 맨 마지막 페이지의 경우 다음으로 갈 수 있는 페이지가 더 이상 없기 떄문임. next 버튼 비활성화
		next=endPage*cri.getPerPageNum()>=totalCount?false:true;
	}
	
	
	
}
