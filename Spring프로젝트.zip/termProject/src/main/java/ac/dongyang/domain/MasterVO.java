package ac.dongyang.domain;

public class MasterVO {

	private String id,pw;

	public void setId(String id) {
		this.id = id;
	}


	public void setPw(String pw) {
		this.pw = pw;
	}


	public String getId() {
		return id;
	}


	public String getPw() {
		return pw;
	}


	
}
