package ac.dongyang.domain;

import java.util.Date;

public class repleVO {
	private String  repler, comment;
	private int repleNo, bno;
	private Date regdate;
	public String getRepler() {
		return repler;
	}
	public void setRepler(String repler) {
		this.repler = repler;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRepleNo() {
		return repleNo;
	}
	public void setRepleNo(int repleNo) {
		this.repleNo = repleNo;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	
	
	
}
