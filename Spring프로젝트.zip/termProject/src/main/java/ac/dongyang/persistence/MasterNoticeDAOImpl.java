package ac.dongyang.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import ac.dongyang.domain.Criteria;
import ac.dongyang.domain.masterNoticeVO;
import ac.dongyang.domain.userVO;


@Repository
public class MasterNoticeDAOImpl implements MasterNoticeDAO {

	@Inject
	private SqlSession session;
	private String namespace = "ac.dongyang.mapper.masterMapper"; 
	@Override
	public void insert(masterNoticeVO vo) {
		session.insert(namespace+".insert",vo);

	}

	@Override
	public List<masterNoticeVO> select(Criteria cri) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".select",cri);
	}

	@Override
	public void delete(int no) {
		session.delete(namespace+".delete",no);

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".getCount");
	}

	@Override
	public masterNoticeVO read(int no) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".read",no);
	}
	
	@Override
	public void deleteUser(String id) {
		// TODO Auto-generated method stub
		 session.selectOne(namespace+".deleteUser",id);
	}

	@Override
	public List<userVO> selectAllUser() {
		// TODO Auto-generated method stub
		 return session.selectList(namespace+".selectAllUser");
	}

	@Override
	public int userCount() {
		// TODO Auto-generated method stub
		 return session.selectOne(namespace+".userCount");
	}

	

}
