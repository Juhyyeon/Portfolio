package ac.dongyang.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import ac.dongyang.domain.FreeBoardVO;

@Repository
public class FreeBoardDAOImpl implements FreeBoardDAO {

	@Inject
	private SqlSession session;
	private String namespace = "ac.dongyang.mapper.freeBoardMapper";
	
	@Override
	public void insert(FreeBoardVO vo) {
		session.insert(namespace+".insert",vo);

	}

	@Override
	public List<FreeBoardVO> select(int num) {

		return session.selectList(namespace+".select",num);
	}

	@Override
	public void delete(int no) {
		session.delete(namespace+".delete",no);
	}

	@Override
	public int getCount() {

		if(session.selectOne(namespace+".selectc")==null)
			return 0;
		return session.selectOne(namespace+".selectc");
		

	}

}
