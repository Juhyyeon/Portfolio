package ac.dongyang.persistence;

import java.util.List;

import ac.dongyang.domain.qnaVO;

public interface QnADAO {

	public void insert(qnaVO vo);
	public List<qnaVO> select();
	public void delete(int qno);
}
