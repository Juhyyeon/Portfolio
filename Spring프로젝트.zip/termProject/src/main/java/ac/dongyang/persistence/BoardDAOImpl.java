package ac.dongyang.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import ac.dongyang.domain.BoardVO;
import ac.dongyang.domain.Criteria;

@Repository
public class BoardDAOImpl implements BoardDAO{

	@Inject
	private SqlSession session;
	private String namespace = "ac.dongyang.mapper.boardMapper";
		
		@Override
		public void create(BoardVO vo) {
			session.insert(namespace+".create",vo);
		}
		@Override
		public BoardVO read(int bno) {
			return session.selectOne(namespace+".read", bno);
		}
		@Override
		public void update(BoardVO vo) {
			session.update(namespace+".update",vo);
		}
		@Override
		public void delete(int bno) {
			session.delete(namespace+".delete",bno);
		}
		@Override
		public List<BoardVO> listAll() {
			return session.selectList(namespace+".listAll");
		}
		
		//�럹�씠吏� 泥섎━ 硫붿냼�뱶 �삤踰꾨씪�씠�뵫
		@Override
		public List<BoardVO> listCriteria(Criteria cri) {
			return session.selectList(namespace+".listCriteria", cri);
		}
		@Override
		public int getTotalCount() {
			// TODO Auto-generated method stub
			return session.selectOne(namespace+".getTotalCount");
		}
		@Override
		public int getSearchTotalCount(Criteria cri) {
			// TODO Auto-generated method stub
			return session.selectOne(namespace+".getTotalCountS",cri);
		}
		@Override
		public List<BoardVO> listCriteriaS(Criteria cri) {
			// TODO Auto-generated method stub
			return session.selectList(namespace+".listCriteriaS",cri);
		}
		@Override
		public void increaseHitCount(BoardVO vo) {
			session.update(namespace+".increaseHitCount",vo);
			
		}


}
