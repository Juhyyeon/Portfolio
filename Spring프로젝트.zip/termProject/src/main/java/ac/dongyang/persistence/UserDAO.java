package ac.dongyang.persistence;

import ac.dongyang.domain.MasterVO;
import ac.dongyang.domain.userVO;
import ac.dongyang.dto.loginDTO;

public interface UserDAO {

	public void regist(userVO vo);
	public userVO login(loginDTO dto) throws Exception;
	public userVO selectUserInfo(String id);
	
	public MasterVO mLogin(MasterVO vo);

	
}
