package ac.dongyang.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import ac.dongyang.domain.MessageVO;

@Repository
public class messageDAOImpl implements messageDAO {

	@Inject
	private SqlSession session;
	private String namespace = "ac.dongynag.mapper.messageMapper";
	
	
	
	@Override
	public void insert(MessageVO vo) {
		session.insert(namespace+".insert",vo);

	}

	@Override
	public List<MessageVO> selectSend(String sender) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".selectSend",sender);
	}

	@Override
	public List<MessageVO> selectReceiver(String receiver) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".selectReceive",receiver);
	}

	@Override
	public int getReceiveCount(String receiver) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".getCount",receiver);
	}

	@Override
	public void deleteS(String sender) {
		session.delete(namespace+".deleteAllS",sender);
		
	}

	@Override
	public void deleteR(String receiver) {
		session.delete(namespace+".deleteAllR",receiver);
		
	}

}
