package ac.dongyang.persistence;

import java.util.List;

import ac.dongyang.domain.BoardVO;
import ac.dongyang.domain.Criteria;

public interface BoardDAO {
	//crud --> create read update delete + list
	
	public void create(BoardVO vo);
	public BoardVO read(int bno);
	public void update(BoardVO vo);
	public void delete(int bno);
	public List<BoardVO> listAll();
	public List<BoardVO> listCriteria(Criteria cri);
	public int getTotalCount();
	public int getSearchTotalCount(Criteria cri);
	public List<BoardVO> listCriteriaS(Criteria cri);
	public void increaseHitCount(BoardVO vo);
		
}
