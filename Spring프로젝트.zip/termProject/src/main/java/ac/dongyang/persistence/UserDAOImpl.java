package ac.dongyang.persistence;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import ac.dongyang.domain.MasterVO;
import ac.dongyang.domain.userVO;
import ac.dongyang.dto.loginDTO;

@Repository
public class UserDAOImpl implements UserDAO {

	@Inject
	private SqlSession session;
	private String namespace = "ac.dongyang.mapper.userMapper";
	@Override
	public void regist(userVO vo) {
		session.insert(namespace+".regist",vo);
	}

	@Override
	public userVO login(loginDTO dto) throws Exception {
		
		return session.selectOne(namespace+".login",dto);
	}
	

	@Override
	public userVO selectUserInfo(String id) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".login",id);
	}

	@Override
	public MasterVO mLogin(MasterVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".masterLogin",vo);
	}

	

}
