package ac.dongyang.persistence;

import java.util.List;

import ac.dongyang.domain.MessageVO;

public interface messageDAO {

	public void insert(MessageVO vo);
	public List<MessageVO> selectSend(String sender);
	public List<MessageVO> selectReceiver(String receiver);
	public int getReceiveCount(String receiver);
	public void deleteS(String sender);
	public void deleteR(String receiver);
}
