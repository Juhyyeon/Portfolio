package ac.dongyang.persistence;

import java.util.List;

import ac.dongyang.domain.repleVO;

public interface RepleDAO {

	public void insert(repleVO rp);
	public void delete(int repleNo);
	public List<repleVO> listAll(int bno);
}
