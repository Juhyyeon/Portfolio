package ac.dongyang.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import ac.dongyang.domain.qnaVO;

@Repository
public class QnADAOImpl implements QnADAO {

	@Inject
	private SqlSession session;
	private String namespace = "ac.dongyang.mapper.qnaMapper";
	
	@Override
	public void insert(qnaVO vo) {
		session.insert(namespace+".insert",vo);
		
	}

	@Override
	public List<qnaVO> select() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".select");
	}

	@Override
	public void delete(int qno) {
		session.delete(namespace+".delete",qno);

	}

}
