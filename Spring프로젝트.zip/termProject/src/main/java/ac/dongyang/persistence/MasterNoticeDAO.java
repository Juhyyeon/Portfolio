package ac.dongyang.persistence;

import java.util.List;

import ac.dongyang.domain.Criteria;
import ac.dongyang.domain.masterNoticeVO;
import ac.dongyang.domain.userVO;

public interface MasterNoticeDAO {

	public void insert(masterNoticeVO vo);
	public List<masterNoticeVO>select(Criteria cri);
	public void delete(int no);
	public int getCount();
	public masterNoticeVO read(int no);
	public void deleteUser(String id);
	public List<userVO> selectAllUser();
	public int userCount();
}
