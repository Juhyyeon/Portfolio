package ac.dongyang.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import ac.dongyang.domain.repleVO;

@Repository
public class RepleDAOImpl implements RepleDAO {
	@Inject
	private SqlSession session;
	private String namespace = "ac.dongyang.mapper.repleMapper";
	
	@Override
	public void insert(repleVO rp) {
		session.insert(namespace+".insert",rp);

	}

	@Override
	public void delete(int repleNo) {
		session.delete(namespace+".delete",repleNo);
	}

	@Override
	public List<repleVO> listAll(int bno) {
		return session.selectList(namespace+".listAll", bno);
	}

}
