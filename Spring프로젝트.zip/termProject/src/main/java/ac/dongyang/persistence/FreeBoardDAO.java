package ac.dongyang.persistence;

import java.util.List;

import ac.dongyang.domain.FreeBoardVO;

public interface FreeBoardDAO {

	public void insert(FreeBoardVO vo);
	public List<FreeBoardVO> select(int num);
	public void delete(int no);
	public int getCount();
}
