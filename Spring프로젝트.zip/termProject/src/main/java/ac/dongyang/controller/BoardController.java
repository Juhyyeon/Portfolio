package ac.dongyang.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ac.dongyang.domain.BoardVO;
import ac.dongyang.domain.Criteria;
import ac.dongyang.domain.FreeBoardVO;
import ac.dongyang.domain.PageMaker;
import ac.dongyang.domain.qnaVO;
import ac.dongyang.domain.repleVO;
import ac.dongyang.persistence.FreeBoardDAO;
import ac.dongyang.persistence.MasterNoticeDAO;
import ac.dongyang.persistence.QnADAO;
import ac.dongyang.persistence.RepleDAO;
import ac.dongyang.service.BoardService;

@Controller
@RequestMapping("/board/*") // 벼룩시장 관련 컨트롤러 클래스
public class BoardController {

	//
	@Inject
	private BoardService service;
	
	@Inject
	private RepleDAO dao;

	@Inject
	private MasterNoticeDAO mndao;
	
	@Inject
	private FreeBoardDAO fbdao;
	
	@Inject
	private QnADAO qnadao;
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String regist(BoardVO vo, RedirectAttributes redir) // 벼룩시장 글 등록 (db에 저장)
	{
		service.create(vo);
		redir.addFlashAttribute("result","글 등록 성공");
		//return "/board/success"; --> 
		return "redirect:/board/listPage";
	}

	@RequestMapping(value="/register", method=RequestMethod.GET)//벼룩시장 글 등록 페이지
	public String register()
	{
		return "/board/registerForm";
	}
	
//	@RequestMapping(value="/listAll",method=RequestMethod.GET)
//	public void list(Model model)
//	{
//		model.addAttribute("list",service.listAll());
//	}
	
	@RequestMapping(value="/read", method=RequestMethod.GET)// 특정 벼룩시장 글 클릭
	public void read(@RequestParam("bno") int bno, Model model) //硫붿냼�뱶 �씠由꾩씠 void�씪�뻹�뒗 views�쓽 jsp�뙆�씪怨� 硫붿냼�뱶�쓽 �씠由꾩씠 移좎튂�빐�빞�븿
	{
		BoardVO myvo = service.read(bno);
		myvo.setViewcnt(myvo.getViewcnt()+1);
		service.increaseHitCount(myvo);
		model.addAttribute("vo",service.read(bno));
		model.addAttribute("bno",bno);
		model.addAttribute("repleVO",dao.listAll(bno));
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.POST) //벼룩시장 글 삭제
	public String delete(@RequestParam("bno") int bno, RedirectAttributes redir)	{
		service.delete(bno);
		redir.addFlashAttribute("result","글 삭제 성공");		
		return "redirect:/board/listPage";
	}
	
	@RequestMapping(value="/update", method=RequestMethod.GET)//벼룩시장 글 수정 페이지
	public void updateGET(int bno, Model model)
	{
		model.addAttribute("vo",service.read(bno));
		
	}
	
	
	@RequestMapping(value="/update", method=RequestMethod.POST)//벼룩시장 글 수정 (db에 수정)
	public String updatePOST(BoardVO vo, RedirectAttributes redir)
	{
		service.update(vo);
		redir.addFlashAttribute("result","글 등록 성공");
		return "redirect:/board/listPage";
	}

	@RequestMapping(value="/listPage",method=RequestMethod.GET)//벼룩시장 글 목록 페이지 (검색기능 추가)
	public void listPage(Model model, Criteria cri,@RequestParam(value="q",defaultValue="",required=false) String q)
	{
		
		if(q.equals("")) // 검색문자열이 없을 경우
		{
		model.addAttribute("list",service.listCriteria(cri));
		PageMaker maker = new PageMaker();
		maker.setCri(cri);
		maker.setTotalCount(service.getTotalCount());
		model.addAttribute("maker",maker);
		}
		else // 검색 문자열이 있을 경우
		{
			cri.setQ(q);
			model.addAttribute("list",service.listCriteriaS(cri));
			model.addAttribute("q",q);
			PageMaker maker = new PageMaker();
			maker.setCri(cri);
			maker.setTotalCount(service.getSearchTotalCount(cri));
			model.addAttribute("maker",maker);
		}
	}
	
	@RequestMapping(value="/repleinsert",method=RequestMethod.POST) // 벼룩시장 글에서 댓글 입력 후
	public String insertReple(repleVO vo) {
	
		int bno=vo.getBno();
		dao.insert(vo);
		
		return "redirect:/board/read?bno="+bno;
	}
	@RequestMapping(value="/repledelete",method=RequestMethod.POST)// 벼룩시장 글에서 댓글 삭제 후
	public String deleteReple(int repleNo,int bno)
	{ 
		dao.delete(repleNo);
		return "redirect:/board/read?bno="+bno;
	}
	@RequestMapping(value="/howToUse") // 이용안내
	public void howToUse()
	{
		
	}
	

	@RequestMapping(value="/notice",method=RequestMethod.GET) // 공지사항 목록
	public void noticeList(Model model, Criteria cri)
	{ 
		model.addAttribute("list",mndao.select(cri));
		PageMaker maker = new PageMaker();
		maker.setCri(cri);
		maker.setTotalCount(mndao.getCount());
		model.addAttribute("maker",maker);
	}
	@RequestMapping(value="/readNotice",method=RequestMethod.GET) // 공지사항 글 클릭
	public void readNotice(Model model,@RequestParam("no") int no)
	{ 
		model.addAttribute("vo",mndao.read(no));

	}
	@RequestMapping(value="/freeBoard") // 자유게시판 
	public void freeBoard(Model model)
	{
		int count = fbdao.getCount();
		if(count>=100)
			count = 100;
		model.addAttribute("freeBoardVO",fbdao.select(count));
	}
	@RequestMapping(value="/freeBoardInsert") // 자유게시판 글 입력
	public String freeBoardInsert(Model model,FreeBoardVO vo)
	{
		fbdao.insert(vo);
		return "redirect:/board/freeBoard";
	}
	@RequestMapping(value="/freeBoardDelete")//자유게시판 글 삭제
	public String freeBoardDelete(Model model,int no)
	{
		fbdao.delete(no);
		return "redirect:/board/freeBoard";
	}
	@RequestMapping(value="/QnA") // QnA 
	public void QnA() 
	{
		
	}
	@RequestMapping(value="/QnADone") //QnA 관리자에게 글 보낼 때
	public String QnADone(qnaVO vo)
	{
		qnadao.insert(vo);
		return "redirect:/board/QnA";
	}
	
	
}
