package ac.dongyang.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ac.dongyang.domain.MessageVO;
import ac.dongyang.domain.masterNoticeVO;
import ac.dongyang.domain.qnaVO;
import ac.dongyang.domain.userVO;
import ac.dongyang.persistence.MasterNoticeDAO;
import ac.dongyang.persistence.QnADAO;
import ac.dongyang.persistence.messageDAO;

@Controller // 관리자 전용 컨트롤러 클래스
public class MasterController {

	
	@Inject
	private MasterNoticeDAO dao;
	
	@Inject
	private QnADAO qnadao;
	@Inject
	private messageDAO msgdao;
	
	@RequestMapping(value="/masterMain")//관리자 메인
	public void masterMain()
	{
		
	}
	@RequestMapping(value="/masterNotice")//관리자 공지 등록 페이지
	public void masterNotice()
	{
		
	}
	@RequestMapping(value="/masterNoticeDone", method=RequestMethod.POST) // 관리자 공지 등록 후 
	public String masterNoticeRegister(masterNoticeVO vo)
	{
		if(vo.getTitle().equals("") || vo.getContent().equals(""))
			return "redirect:/masterMain";
		dao.insert(vo);
		return "redirect:/masterMain";
	}
	@RequestMapping(value="/masterMail") //관리자 전체쪽지
	public void masterMail()
	{
		
	}
	@RequestMapping(value="/masterReple") // 관리자 QnA 답변
	public void masterReple(Model model)
	{
		model.addAttribute("QnAVO",qnadao.select());
	}
	@RequestMapping(value="/masterRemID") // 관리자 불량유저 삭제 페이지
	public void masterRemID(Model model)
	{
		model.addAttribute("userVO",dao.selectAllUser());
	}
	
	@RequestMapping(value="/masterSend")// 관리자 전체쪽지 보내기
	public void masterSend(@RequestParam(value="writer",required=false) String writer, @RequestParam(value="Qno",required=false) int qno,Model model)
	{
		model.addAttribute("writer",writer);
		model.addAttribute("Qno",qno);
	}
	@RequestMapping(value="/masterSendOK")//관리자 전체쪽지 보내고 난 후
	public String masterSendOK(qnaVO vo)
	{
		MessageVO mvo = new MessageVO();
		
		mvo.setMessage(vo.getContent());
		mvo.setReceiver(vo.getWriter());
		mvo.setSender("master");
		msgdao.insert(mvo);
		qnadao.delete(vo.getQno());
		
		return "redirect:/masterReple";
	}
	
	@RequestMapping(value="/masterRemIDOK")//관리자 불량유저 삭제 후
	public String masterRemIDOK(@RequestParam(value="id",required=false) String id)
	{
		dao.deleteUser(id);
		//masterMain으로 바꾸기
		return "redirect:/masterRemID";
	}
	@RequestMapping(value="/masterMailOK",method=RequestMethod.POST)//관리자 전체쪽지 보내고 난 후
	public String masterMailOK(@RequestParam(value="comment",required=false) String comment,MessageVO vo)
	{
		List<userVO> mylist = dao.selectAllUser();
		
		for(int i=0;i<dao.userCount();i++)
		{
			vo.setMessage(comment);
			vo.setReceiver(mylist.get(i).getId());
			vo.setSender("master");
			msgdao.insert(vo);
		}
		
		return "redirect:/masterMail";
	}
	
	@RequestMapping(value="/adminNotice")//관리자 이용안내
	public void adminNotice()
	{
		
	}
	
}
