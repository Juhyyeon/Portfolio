package ac.dongyang.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ac.dongyang.domain.MessageVO;
import ac.dongyang.persistence.messageDAO;

@Controller//쪽지 관련 컨트롤러 클래스
@RequestMapping("/message/*")
public class MessageController {

	@Inject
	private messageDAO dao;
	
	@RequestMapping(value="/message/sendMessage")//쪽지 보내기 페이지
	public void sendMessage()
	{
		
	}

	@RequestMapping(value="/insert")//쪽지 작성
	public String insert(@RequestParam(value="master",required=false) String master, Model model)
	{
		return "/message/sendMessage";
	}
	
	@RequestMapping(value="/insertGood",method=RequestMethod.POST)//쪽지 작성 후
	public String insertGood(MessageVO vo)
	{
		dao.insert(vo);
		return "redirect:/message/sendMessage";
	}
	
	@RequestMapping(value="/receiveList")//받은 메시지함
	public void receiveList(Model model,@RequestParam(value="receiver",required=false) String receiver)
	{
		
		model.addAttribute("mylist",dao.selectReceiver(receiver));
	}
	@RequestMapping(value="/sendList")//보낸 메시지함
	public void sendList(Model model,@RequestParam(value="sender",required=false) String sender)
	{
		
		model.addAttribute("mylist",dao.selectSend(sender));
	}
	@RequestMapping(value="/deleteR")//받은 메시지함 전체 삭제
	public String deleteR(Model model,@RequestParam(value="receiver",required=false) String receiver)
	{
		dao.deleteR(receiver);
		return "redirect:/message/receiveList";
	}
	@RequestMapping(value="/deleteS")//보낸 메시지함 전체 삭제
	public String deleteS(Model model,@RequestParam(value="sender",required=false) String sender)
	{
		
		dao.deleteS(sender);
		return "redirect:/message/sendList";
	}
}
