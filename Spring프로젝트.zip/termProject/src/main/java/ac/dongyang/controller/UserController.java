package ac.dongyang.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ac.dongyang.domain.MasterVO;
import ac.dongyang.domain.userVO;

import ac.dongyang.dto.loginDTO;
import ac.dongyang.persistence.UserDAO;

@Controller//회원 관련 컨트롤러
@RequestMapping("/board/user/*")
public class UserController {

	@Inject
	private UserDAO dao;
	
	@RequestMapping("/userRegister")//유저 회원가입 페이지
	public void userRegister()
	{
		
	}
	
	@RequestMapping(value="/checkRegister")//유저 회원가입 
	public String registGET(userVO vo)
	{
		dao.regist(vo);
		return "/board/user/registDone";
	}
	
	
	@RequestMapping(value="/checkRegister", method=RequestMethod.POST)//유저 회원가입 후
	public String registPOST(userVO vo)
	{
		dao.regist(vo);
		return "/board/user/registDone";
	}
	
	@RequestMapping(value="/login",  method=RequestMethod.GET)//로그인 페이지
	public void loginGET(@ModelAttribute("dto") loginDTO dto)
	{
		
	}
	@RequestMapping(value="/loginPost",  method=RequestMethod.POST)//로그인 후
	public void loginPOST(loginDTO dto, HttpSession session, Model model) throws Exception
	{
		userVO vo = dao.login(dto);
		if(vo==null)
		{
			return ;
		}
		model.addAttribute("userVO", vo);
	}
	@RequestMapping(value="/logout",  method=RequestMethod.GET)//로그아웃
	public void logout()
	{
		
	}

	@RequestMapping(value="/index", method=RequestMethod.GET)//관리자 로그인 창
	public void master()
	{
		
	}
	@RequestMapping(value="/index", method=RequestMethod.POST)//관리자 로그인 후 (세션 적용)
	public String masterPost(MasterVO vo,RedirectAttributes rttr,HttpServletRequest request)
	{
		MasterVO myvo = dao.mLogin(vo);
		if(myvo!=null)
		{

		HttpSession session = request.getSession();
		session.setAttribute("MLOGIN",myvo);
		rttr.addFlashAttribute("masterID",vo.getId());
		return "redirect:/masterMain";
		}
		else
		{

			return "/board/user/index";
		}
	}



	
	
}
